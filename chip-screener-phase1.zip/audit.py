"""python audit.py [--fetch | --run 版本]。預設離線重播。"""

import argparse
import csv
import json
import os
import re
import tempfile
from datetime import date, datetime
from pathlib import Path
from chip import store
from chip.coverage import profile
from chip.market import daily, exchange_days, samples
from chip.signal import STRATEGY
from chip.sources import CASE, CUTOFF
from chip.weekly import require, weekly


def save_csv(path, rows):
    cols = dict.fromkeys(k for r in rows for k in r)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(cols))
        w.writeheader()
        w.writerows(rows)


def analyse(run):
    require(re.fullmatch(r"\d{8}T\d{12}", run), "無效資料版本")
    a = store.Archive(run)
    dates = exchange_days(a)
    bars, warm, divs = daily(a, dates)
    require(
        len(bars) == 697 and all(r["status"] == "回補值相符" for r in bars),
        "固定區間的日行情／股數缺漏或來源不符",
    )
    market_samples = samples(a)
    grades, points, signals, replay, week_meta = weekly(a, list(map(date.fromisoformat, dates)))
    coverage = [profile(a, k, v) for k, v in a.manifest.items()]
    lookup = {r["source"]: r for r in coverage}
    for ds, t in week_meta["known"].items():
        lookup["TDCC_" + ds]["historical_observed_by"] = t
    # 同期備份有各市場各自的統計日。逐欄核對後才給行情時間戳。
    mirror = a.json("行情備份")["symbols"]
    sha = a.manifest["行情備份"]["url"].split("/")[5]
    t = min(
        (
            r["timestamp"]
            for r in a.json("行情備份推送")
            if r["after"] == sha and r["ref"] == "refs/heads/main"
        ),
        default=None,
    )
    time_bound = datetime.fromisoformat(t).astimezone(store.TZ).isoformat() if t else None
    k = mirror["2404"]
    bar = next(r for r in bars if r["date"] == k["tradeDate"])
    require(
        all(
            bar[u] == k[v]
            for u, v in [
                ("volume_shares", "volume"),
                ("amount_ntd", "value"),
                ("high", "high"),
                ("low", "low"),
                ("open", "open"),
                ("close", "close"),
            ]
        ),
        "同期行情檔與逐日原值不合",
    )
    bar["price_observed_by"] = time_bound
    shares_day = next(r for r in bars if r["date"] == "2026-03-12")
    require(
        shares_day["issued_shares"] == 190586698 and "190,586,698" in a.raw("公告_漢唐股數").decode(),
        "公司公告股數不合",
    )
    shares_day["shares_observed_by"] = lookup["公告_漢唐股數"]["historical_observed_by"]
    lookup["行情備份"]["historical_observed_by"] = time_bound
    signals_400 = next(s for s in signals if s["band"] == "400")
    require(signals_400["state"] == "通過", "漢唐案例未達標，保留先前通過版本，請查資料修訂")
    otc = next(r for r in market_samples if r["code"] == "3105" and r.get("issued_shares"))
    require(
        signals_400["delta_shares"] == [796897, 579084]
        and signals_400["total_pp_exact"] == "68799050/95293349",
        "三期固定樣本股數已修訂，請對照原始版本",
    )
    audit = dict(
        data_version=run,
        spec="v0.4",
        strategy_version=STRATEGY,
        cutoff=CUTOFF,
        settings={
            "threshold_pp": "0.20",
            "consecutive_changes": 2,
            "require_increasing_shares": True,
            "default_band_lots": 400,
            "bands_lots": [200, 400, 600, 1000],
            "max_relative_inventory_change": "0.01",
        },
        case_dates=CASE,
        week_evidence=week_meta,
        weekly=signals,
        daily=dict(
            rows=len(bars),
            matched=sum(r["status"] == "回補值相符" for r in bars),
            start=dates[0],
            end=dates[-1],
            issued_shares=sorted({r["issued_shares"] for r in bars if r.get("issued_shares")}),
            verified_issued_dates=[r["date"] for r in bars if r.get("official_share_check")],
            strict_warmup_start=None,
            warmup=warm,
            cash_ex_dates=divs,
        ),
        backup_quote=dict(
            trade_date_2404=k["tradeDate"],
            known_by=time_bound,
            trade_date_3105=mirror["3105"]["tradeDate"],
            volume_3105_backup=mirror["3105"]["volume"],
            volume_3105_exchange=otc["volume_shares"],
        ),
        split_4763=dict(
            stop="2025-06-19",
            registry_change="2025-06-27",
            resume="2025-06-30",
            old_shares=98914667,
            new_shares=989146670,
            ratio=10,
            announcement="2025-06-04T11:19:15+08:00",
        ),
        complete_strict_performance_period=None,
    )
    out = store.ROOT / "reports" / run
    out.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=out) as temp:
        stage = Path(temp)
        for name, rows in [
            ("coverage", coverage),
            ("levels", grades),
            ("weekly", points),
            ("replay", replay),
            ("daily_2404", bars),
            ("market_samples", market_samples),
        ]:
            save_csv(stage / (name + ".csv"), rows)
        store.write_json(stage / "result.json", audit)
        for p in stage.iterdir():
            os.replace(p, out / p.name)
    return out


def refresh():
    run = store.download()
    try:
        out = analyse(run)
    except (OSError, ValueError, KeyError, IndexError, StopIteration) as exc:
        store.write_json(
            store.DATA / "rejections" / (run + ".json"),
            {"data_version": run, "checked_at": store.now(), "reason": str(exc)},
        )
        raise
    tmp = store.DATA / (run + ".pointer")
    tmp.write_text(run, encoding="ascii")
    os.replace(tmp, store.DATA / "latest.txt")
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument("--fetch", action="store_true", help="重新下載並驗收固定樣本")
    group.add_argument("--run", help="重播指定清單的版本")
    group.add_argument("--status", action="store_true", help="列出最近嘗試、最後成功版本與失敗原因")
    args = parser.parse_args()
    if args.fetch:
        print(refresh())
    elif args.status:
        manifests = sorted((store.DATA / "runs").glob("*.json"))
        latest = store.DATA / "latest.txt"
        good = latest.read_text(encoding="ascii").strip() if latest.exists() else None
        last = manifests[-1].stem if manifests else None
        failures = {
            k: v["error"]
            for k, v in (json.loads(manifests[-1].read_text(encoding="utf-8")) if last else {}).items()
            if "error" in v
        }
        rejected = store.DATA / "rejections" / f"{last}.json"
        if rejected.exists():
            failures["內容驗收"] = json.loads(rejected.read_text(encoding="utf-8"))["reason"]
        print(
            json.dumps(
                {"最近嘗試": last, "最後成功": good, "沿用舊版": last != good, "異常": failures},
                ensure_ascii=False,
                indent=2,
            )
        )
    else:
        print(analyse(args.run or (store.DATA / "latest.txt").read_text(encoding="ascii").strip()))
