import csv
import hashlib
import json
import tempfile
import unittest
from datetime import date, datetime
from fractions import Fraction
from pathlib import Path
from unittest.mock import patch
import audit
from chip import store
from chip.signal import Point, classify
from chip.weekly import levels
from chip.sources import CASE

FIXTURE = json.loads(Path(__file__).with_name("cases.json").read_text(encoding="utf-8"))


def simulate(spec):
    rows = [list(r) for r in FIXTURE["regular"]]
    if "replace_date" in spec:
        i, ds = spec["replace_date"]
        rows[i][0] = ds
    if "replace_shares" in spec:
        i, n, total = spec["replace_shares"]
        rows[i][2:] = [n, total]
    if "unknown" in spec:
        rows[spec["unknown"]][1] = None
    expected = [date.fromisoformat(ds) for ds in FIXTURE["expected_dates"]]
    if spec.get("use_input_dates"):
        expected = [date.fromisoformat(r[0]) for r in rows]
    pts = {}
    for i, (ds, t, n, total) in enumerate(rows):
        if spec.get("omit") == i:
            continue
        day = date.fromisoformat(ds)
        pts[day] = Point(day, datetime.fromisoformat(t) if t else None, n, 5, total, 100)
    as_of = datetime.fromisoformat(spec.get("as_of", FIXTURE["as_of"]))
    return classify(pts, expected, as_of)


class SignalTest(unittest.TestCase):
    def test_synthetic(self):
        for case in FIXTURE["cases"]:
            with self.subTest(case=case["name"]):
                result = simulate(case)
                self.assertEqual(result["state"], case["expected"])
                for field in ("ratio_only", "shares_both"):
                    if field in case:
                        self.assertEqual(result[field], case[field])
                if "delta_pp" in case:
                    self.assertEqual(result["delta_pp"], list(map(Fraction, case["delta_pp"])))
                    self.assertEqual(result["total_pp"], Fraction(case["total_pp"]))
                if result["state"] in ("缺週", "尚無可用證據"):
                    self.assertEqual(set(result), {"state"})


class ArchiveTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.run_id = (store.DATA / "latest.txt").read_text(encoding="ascii")
        cls.archive = store.Archive(cls.run_id)

    def test_replay_and_exact_case(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(store, "ROOT", Path(tmp)):
            out = audit.analyse(self.run_id)
            h = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}
            audit.analyse(self.run_id)
            self.assertEqual(h, {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()})
            res = json.loads((out / "result.json").read_text(encoding="utf-8"))
            byband = {s["band"]: s for s in res["weekly"]}
            self.assertEqual(byband["400"]["delta_shares"], [796897, 579084])
            self.assertEqual(byband["400"]["total_pp_exact"], "68799050/95293349")
            self.assertEqual(byband["400"]["eligible_open"], "2026-11-16T09:00:00+08:00")
            self.assertEqual(byband["200"]["state"], "比例未連升")
            self.assertIsNone(byband["200"]["eligible_open"])
            self.assertFalse(byband["1000"]["weekly_005"])
            self.assertEqual(res["daily"]["matched"], 697)
            with (out / "weekly.csv").open(encoding="utf-8-sig") as f:
                w = [r for r in csv.DictReader(f) if r["band"] == "400" and r["snapshot"] in CASE]
            self.assertEqual([round(float(r["percent"]), 3) for r in w], [55.496, 55.914, 56.218])

    def test_real_asof_boundary(self):
        from chip.weekly import weekly
        from chip.market import exchange_days

        _, rows, _, _, _ = weekly(self.archive, list(map(date.fromisoformat, exchange_days(self.archive))))
        pts = {}
        for r in rows:
            if r["band"] == "400":
                d = date.fromisoformat(r["snapshot"])
                pts[d] = Point(
                    d,
                    datetime.fromisoformat(r["observed_by"]),
                    r["shares"],
                    r["holders"],
                    r["total_shares"],
                    r["total_holders"],
                )
        expected = list(map(date.fromisoformat, CASE))
        self.assertEqual(
            classify(pts, expected, datetime.fromisoformat("2026-11-13T15:00:00+08:00")),
            {"state": "尚無可用證據"},
        )
        self.assertEqual(classify(pts, expected, pts[expected[-1]].known)["state"], "通過")

    def test_reject_duplicate_grade(self):
        b = self.archive.raw("TDCC_" + CASE[-1])
        row = next(r for r in b.splitlines() if b",2404 " in r)
        with self.assertRaisesRegex(ValueError, "重複"):
            levels(b + b"\n" + row, CASE[-1])

    def test_failed_refresh_preserves_last_good(self):
        with tempfile.TemporaryDirectory() as tmp, patch.object(store, "DATA", Path(tmp)):
            pointer = Path(tmp) / "latest.txt"
            pointer.write_text(self.run_id, encoding="ascii")
            with (
                patch.object(store, "catalog", return_value={"失敗抽樣": "test"}),
                patch.object(
                    store, "fetch", return_value=("失敗抽樣", {"url": "test", "error": "模擬來源逾時"})
                ),
            ):
                with self.assertRaises(SystemExit):
                    audit.refresh()
            self.assertEqual(pointer.read_text(), self.run_id)
            failed = json.loads(next((Path(tmp) / "runs").glob("*.json")).read_text(encoding="utf-8"))
            self.assertIn("error", failed["失敗抽樣"])
            with (
                patch.object(store, "download", return_value="candidate"),
                patch.object(audit, "analyse", side_effect=ValueError("級距缺漏")),
            ):
                with self.assertRaises(ValueError):
                    audit.refresh()
            self.assertEqual(pointer.read_text(), self.run_id)
