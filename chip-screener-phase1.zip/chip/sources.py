"""第一輪固定取樣清單。每個網址都是匿名讀取。"""

from urllib.parse import urlencode

TW = "https://www.twse.com.tw/rwd/zh/"
OTC = "https://www.tpex.org.tw/www/zh-tw/"
REPO = "wirelessr/tdcc-opendata-archive"
GH = "https://api.github.com/repos/" + REPO
RAW = "https://raw.githubusercontent.com/" + REPO + "/"
# 各期新增快照的 main push；以伺服器活動時間核對，不採用作者時鐘。
COMMITS = {
    "2026-07-09": "aa730cee3c02e8c5ec725d8cee31c1d3a42806d7",
    "2026-10-16": "2ca270a9a90557f2bd9165e27e8c39e635e41aca",
    "2026-10-22": "1d7e9eb965dfd030ac687a0cd463514394373df5",
    "2026-10-30": "295bbc0b468834a98bb2242d10e1c369db654136",
    "2026-11-06": "252fa5801a3ad7d80261ff8ee4cae2b21a0332ac",
    "2026-11-13": "14e11200b914a8badddba114450586e2ed368604",
}
CASE = list(COMMITS)[-3:]
CUTOFF = "2026-11-19"


def fin(table, code, start, end=CUTOFF):
    params = {"dataset": "TaiwanStock" + table}
    if code:
        params["data_id"] = code
    params.update(start_date=start, end_date=end)
    return "https://api.finmindtrade.com/api/v4/data?" + urlencode(params)


def kbar(code, month):
    return TW + f"afterTrading/STOCK_DAY?date={month}01&stockNo={code}&response=json"


def catalog():
    urls = {
        "集保官方最新": "https://opendata.tdcc.com.tw/getOD.ashx?id=1-5",
        "集保授權": "https://data.gov.tw/api/v2/rest/dataset/11452",
        "備份說明": RAW + COMMITS[CASE[-1]] + "/README.md",
        "備份性質": GH,
        "推送活動": GH + "/activity?per_page=100",
        "公開事件": GH + "/events?per_page=100",
        "排程紀錄": GH + "/actions/runs?created=2026-10-30..2026-11-17&per_page=100",
        "日曆年度": TW + "holidaySchedule/holidaySchedule?date=20260101&response=json",
        "日曆備援": fin("TradingDate", "", "2024-01-01"),
        "面額變更": TW + "change/TWTB8U?startDate=20240101&endDate=20261119&response=json",
        "分割明細": TW
        + "change/TWTB8UDetail?STK_NO=4763&STOP_DATE=20250619&RESUME_DATE=20250630&response=json",
        "下市": TW + "company/suspendListing?response=json",
        "新上市": TW + "company/newlisting?response=json",
        "TPEx_日表": OTC + "afterTrading/dailyQuotes?date=2026/11/13&response=json",
        "TPEx_股數": OTC + "insti/qfii?date=2026/11/13&response=json",
        "TPEx_3105_月表": OTC + "afterTrading/tradingStock?code=3105&date=2026/11/01&response=json",
    }
    for day, commit in COMMITS.items():
        urls["TDCC_" + day] = RAW + commit + f"/snapshots/2026/{day}.csv"
    for year in (2024, 2025, 2026):
        for month in range(1, 12 if year == 2026 else 13):
            ym = f"{year}{month:02d}"
            urls["TW_2404_" + ym] = kbar("2404", ym)
            urls["日曆_" + ym] = TW + f"afterTrading/FMTQIK?date={ym}01&response=json"
        end = min(f"{year}1231", "20261119")
        urls[f"除權息_{year}"] = TW + f"exRight/TWT49U?startDate={year}0101&endDate={end}&response=json"
    for code, month in [("2888", "202507"), ("4763", "202506"), ("7867", "202610"), ("2330", "202611")]:
        urls["TW_" + code + "_" + month] = kbar(code, month)
    for day in [
        "20240102",
        "20250717",
        "20250618",
        "20250627",
        "20250630",
        "20260312",
        "20261030",
        "20261106",
        "20261113",
        "20261119",
    ]:
        urls["TW_股數_" + day] = TW + f"fund/MI_QFIIS?date={day}&selectType=ALLBUT0999&response=json"
    for code, start, end in [
        ("2404", "2024-01-01", CUTOFF),
        ("3105", "2026-11-01", CUTOFF),
        ("3067", "2026-11-13", "2026-11-13"),
        ("4763", "2025-06-17", "2025-06-30"),
    ]:
        for table in ("Price", "Shareholding"):
            urls[f"FM_{code}_{table}"] = fin(table, code, start, end)
    urls["FM_2404_息"] = fin("DividendResult", "2404", "2024-01-01")
    for day in CASE:
        urls["集保個股_" + day] = "https://www.tdcc.com.tw/portal/zh/smWeb/qryStock"
    urls["公告_分割"] = "https://m.cnyes.com/news/print/6006356"
    urls["公告_除息"] = "https://news.ustv.com.tw/companynews/231845"
    urls["FM_2404_減資"] = fin("CapitalReductionReferencePrice", "2404", "2024-01-01")
    urls["公告_漢唐股數"] = "https://news.cnyes.com/news/print/6381526"
    urls["行情備份推送"] = (
        "https://api.github.com/repos/u159753123-G/codex-taiwan-market-data/activity?per_page=100"
    )
    urls["行情備份"] = (
        "https://raw.githubusercontent.com/u159753123-G/codex-taiwan-market-data/01a2043400525b1f8ec3352099a6483c520395ec/data/market/codex_stock_prices_latest.json"
    )
    return urls
