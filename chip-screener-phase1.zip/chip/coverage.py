"""每筆請求的覆蓋表。期間只描述本輪實際核對的樣本。"""

import csv
import io
from .market import roc
from .sources import CUTOFF
from datetime import datetime


def profile(a, key, meta):
    doc = None
    ds = []
    fields = ""
    codes = ""
    units = ""
    limitation = ""
    strict = "未取得同期版本"
    observed = None
    release = None
    count = None
    if key.startswith("TDCC_") or key == "集保官方最新":
        reader = csv.DictReader(io.StringIO(a.raw(key).decode("utf-8-sig")))
        fields = "、".join(reader.fieldnames)
        sample = [r for r in reader if r["證券代號"].strip() == "2404"]
        ds = [datetime.strptime(r["資料日期"], "%Y%m%d").date().isoformat() for r in sample]
        count = len(sample)
        codes = "2404 上市"
        units = "股、人、%；1 張 = 1,000 股"
        limitation = "最新 CSV 滾動覆寫；備份採固定 commit"
        strict = "時間證據見 weekly.csv；單週尚需另兩期組窗"
    elif key.startswith("集保個股_"):
        ds = [key[-10:]]
        codes = "2404 上市"
        fields = "級次、持股區間、人數、股數、占比"
        units = "人、股、%"
        count = 16
        limitation = "查詢需先 GET 再帶表單權杖及日期 POST；官網揭示保留一年；依合計標籤辨認分母"
    elif key == "公告_漢唐股數":
        ds = ["2026-03-12"]
        codes = "2404 上市"
        count = 1
        fields = "發言日期時間、發行股數、庫藏股、可分配股數"
        units = "股"
        release = "2026-03-12T17:46:58+08:00"
        observed = "2026-03-12T17:47:00+08:00"
        limitation = "重訊轉載；轉載頁時間精確至分鐘，採下一分鐘，僅證明當日分母"
        strict = "單一分母錨點"
    elif key == "行情備份":
        d = a.json(key)
        fields = "、".join(d["symbols"]["2404"])
        ds = [d["symbols"][c]["tradeDate"] for c in ["2404", "3105"]]
        codes = "2404 上市、3105 上櫃"
        count = 2
        units = "股、元"
        limitation = "須按每檔 tradeDate；3105 成交範圍與日表不同"
        strict = "只承認 2404 比對相同的行情欄位"
    elif key == "行情備份推送":
        ds = [r["timestamp"][:10] for r in a.json(key)]
        count = len(ds)
        fields = "after、ref、timestamp"
        units = "UTC"
        limitation = "行情備份的伺服器時戳"
    elif key.startswith("公告_"):
        ds = ["2026-07-16" if key == "公告_除息" else "2025-06-30"]
        codes = "2404 上市" if key == "公告_除息" else "4763 上市"
        fields = "公司、公告時間、現金股利／換股時程"
        units = "元／股、日期、換股比率"
        count = 1
        if key == "公告_分割":
            release = "2025-06-04T11:19:15+08:00"
        observed = "2026-06-18T15:27:00+08:00" if key == "公告_除息" else "2025-06-04T11:20:00+08:00"
        limitation = (
            "轉載重大訊息，除息頁時間只有分鐘，採下一分鐘；分割轉載時間同樣取下一分鐘，另記發言秒數"
        )
        strict = "僅能用作該事件證據"
    elif key in ("集保授權", "備份說明", "備份性質", "推送活動", "公開事件", "排程紀錄"):
        fields = {
            "集保授權": "datasetId、license、資料資源",
            "備份說明": "README",
            "備份性質": "full_name、private",
            "推送活動": "activity_type、ref、after、timestamp、id",
            "公開事件": "public、created_at、payload.head",
            "排程紀錄": "head_sha、created_at、conclusion",
        }[key]
        limitation = "授權／版本證據；GitHub 活動列表有保留上限，舊時點用凍結回應重播"
        if key == "推送活動":
            ds = [r["timestamp"][:10] for r in a.json(key)]
            count = len(ds)
            units = "伺服器 UTC，週表轉台北"
        if key == "公開事件":
            ds = [r["created_at"][:10] for r in a.json(key)]
            count = len(ds)
        if key == "排程紀錄":
            ds = [r["created_at"][:10] for r in a.json(key)["workflow_runs"]]
            count = len(ds)
    else:
        doc = a.json(key)
        tb = doc.get("tables", [doc])[0]
        rr = tb.get("data", [])
        fields = "、".join(tb.get("fields", list(rr[0]) if rr and isinstance(rr[0], dict) else []))
        if key.startswith("FM_") or key == "日曆備援":
            ds = [r["date"] for r in rr]
            codes = key.split("_")[1] if key.startswith("FM_") else "台股市場"
            units = (
                "OHLC 元、成交股數、成交金額元、筆"
                if key.endswith("Price")
                else "發行與外資持股以股計，比率 %"
                if key.endswith("Shareholding")
                else "每股新台幣元、日期"
                if key.endswith("息")
                else "日期"
            )
            limitation = "免費匿名、非商業、須註明 FinMind；當次回補。無資料列不代表所有公司行動已覆核"
        elif key.startswith("TW_股數_"):
            codes = "2404 上市" + (
                "、4763 上市" if key[-8:] in ("20250618", "20250627", "20250630") else ""
            )
            rr = [r for r in rr if r[0] == "2404" or (r[0] == "4763" and "4763" in codes)]
            ds = [datetime.strptime(doc["date"], "%Y%m%d").date().isoformat()] * len(rr)
            units = "股、%、民國申報日"
            limitation = "單日全表，抽取指定代號；最近申報日不等於本表公開時間"
        elif key.startswith(("TW_", "日曆_")) or key == "TPEx_3105_月表":
            ds = [roc(r[0]) for r in rr if roc(r[0]) <= CUTOFF]
            codes = key.split("_")[1] + " 上市" if key.startswith("TW_") else "集中市場"
            units = "元、股、筆" + ("、指數點" if key.startswith("日曆_") else "")
            limitation = "月查詢，限制至研究截點；TWSE 含一般、零股、盤後定價及鉅額，不含拍賣標購"
            if key.startswith("TPEx"):
                units = "成交張數、仟元、股價元、筆"
                codes = "3105 上櫃"
                limitation = "月表捨入且排除鉅額；精確量另對日表與 FinMind"
        elif key in ("TPEx_日表", "TPEx_股數"):
            codes = "3105、1259、3067 上櫃"
            idx = 0 if key == "TPEx_日表" else 1
            rr = [r for r in rr if r[idx] in ("3105", "1259", "3067")]
            ds = ["2026-11-13"] * len(rr)
            units = "股、元、筆、張（委託量）" if idx == 0 else "股、%"
            limitation = "只取指定普通股；零量未報 OHLC 保留空值"
        elif key == "日曆年度":
            ds = [r[0] for r in rr]
            units = "西元日"
            codes = "集中市場"
            limitation = "年度計畫含未來節日，逐月市場成交實績另核"
        elif key in ("下市", "新上市"):
            rr = [r for r in rr if (r[2] == "2888" if key == "下市" else r[0] == "7867")]
            ds = [roc(r[0] if key == "下市" else r[9]) for r in rr]
            codes = "2888 新光金" if key == "下市" else "7867 特力屋"
            units = "事件日"
            limitation = "只查指定掛牌事件"
        else:
            samplecode = "2404" if key.startswith("除權息_") else "4763"
            rr = [r for r in rr if r[1] == samplecode]
            ds = [roc(r[0]) for r in rr]
            codes = samplecode + " 上市"
            units = "每股新台幣元、日期"
            limitation = "事件日與公告分列；除權息查詢另帶較晚財報欄，未供訊號使用"
        count = len(ds)
    return dict(
        source=key,
        stocks=codes,
        start=min(ds, default=None),
        end=max(ds, default=None),
        sample_rows=count,
        fields=fields,
        units=units,
        official_release=release,
        historical_observed_by=observed,
        downloaded_at=meta["downloaded_at"],
        limits=limitation,
        strict_scope=strict,
        url=meta["url"],
        raw="evidence/raw/" + meta["sha256"] + ".gz",
        bytes=meta["bytes"],
    )
