"""純函式。盤後掃描與時點重播皆傳入同一個 as_of；門檻單位是百分點。"""

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from fractions import Fraction

BANDS = {"200": (11, 15), "400": (12, 15), "600": (13, 15), "1000": (15, 15), "400–1000": (12, 14)}
STRATEGY = "tdcc-2w/1"
DEFAULT_PP = Fraction("0.20")


@dataclass(frozen=True)
class Point:
    day: date
    known: datetime | None
    shares: int
    holders: int
    total: int
    total_holders: int

    @property
    def percent(self):
        return Fraction(100 * self.shares, self.total)


def week(day):
    return day - timedelta(days=day.weekday())


def classify(points, expected, as_of, minimum_pp=DEFAULT_PP):
    if as_of.tzinfo is None:
        raise ValueError("as_of 必須包含時區")
    if len(expected) != 3 or any(
        week(b) - week(a) != timedelta(days=7) for a, b in zip(expected, expected[1:])
    ):
        return {"state": "缺週"}
    visible = []
    for day in expected:
        point = points.get(day)
        if point is None:
            return {"state": "缺週"}
        if point.known is None or point.known > as_of:
            return {"state": "尚無可用證據"}
        if point.day != day or not (0 <= point.shares <= point.total and point.total > 0):
            return {"state": "資料異常"}
        visible.append(point)
    delta = [b.percent - a.percent for a, b in zip(visible, visible[1:])]
    shares = [b.shares - a.shares for a, b in zip(visible, visible[1:])]
    both = min(delta) > 0
    gain = sum(delta)
    magnitude = next(
        (
            name
            for limit, name in [
                (1, "強增加"),
                (Fraction("0.50"), "明顯"),
                (Fraction("0.20"), "一般"),
                (Fraction("0.10"), "小幅"),
                (0, "微升"),
            ]
            if gain > 0 and gain >= limit
        ),
        "未增加",
    )
    risk = any(p.total_holders <= 1 for p in visible) or any(
        abs(Fraction(b.total - a.total, a.total)) > Fraction("0.01") for a, b in zip(visible, visible[1:])
    )
    if risk:
        state = "分母或總戶數異常"
    elif not both:
        state = "比例未連升"
    elif min(shares) <= 0:
        state = "比例連升但股數未連增"
    elif gain < minimum_pp:
        state = "連升但未達累計門檻"
    else:
        state = "通過"
    return dict(
        state=state,
        ratio_only=both,
        shares_both=min(shares) > 0,
        weekly_005=min(delta) >= Fraction("0.05"),
        group=magnitude,
        delta_pp=delta,
        total_pp=gain,
        delta_shares=shares,
    )
