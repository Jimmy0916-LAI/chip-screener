from datetime import date
from decimal import Decimal
from math import prod
import re
from .sources import CUTOFF
from .weekly import require


def roc(value):
    y, m, d = map(int, re.findall(r"\d+", value))
    return date(y + 1911, m, d).isoformat()


def number(value):
    return Decimal(str(value).replace(",", ""))


def indexed(rows, key):
    result = {r[key]: r for r in rows}
    require(len(rows) == len(result), "重複日期或代號")
    return result


def exchange_days(a):
    dates = []
    for k in sorted(a.manifest):
        if k.startswith("日曆_"):
            dates.extend(roc(r[0]) for r in a.json(k)["data"] if roc(r[0]) <= CUTOFF)
    require(sorted(set(dates)) == dates, "交易日重複或排序不符")
    backup = [r["date"] for r in a.json("日曆備援")["data"]]
    require(dates == backup, "日曆來源有落差")
    return dates


def daily(a, dates):
    prices = indexed(a.json("FM_2404_Price")["data"], "date")
    issued = indexed(a.json("FM_2404_Shareholding")["data"], "date")
    official = {}
    for k in sorted(a.manifest):
        if k.startswith("TW_2404_"):
            table = a.json(k)
            require("2404 漢唐" in table["title"] and table["fields"][1] == "成交股數", k)
            for r in table["data"]:
                ds = roc(r[0])
                require(ds not in official, "官方行情重複")
                official[ds] = r
    anchors = {}
    for key in a.manifest:
        if key.startswith("TW_股數_"):
            table = a.json(key)
            ds = table["date"]
            require(ds == key[-8:], "外資表日期不符")
            row = indexed(table["data"], 0)["2404"]
            anchors[date.fromisoformat(ds).isoformat()] = int(number(row[3]))
    dividends = {}
    fm = indexed(a.json("FM_2404_息")["data"], "date")
    for y in [2024, 2025, 2026]:
        for r in a.json("除權息_" + str(y))["data"]:
            if r[1] == "2404":
                ds = roc(r[0])
                require(
                    r[6] == "息"
                    and ds in fm
                    and number(r[5]) == number(fm[ds]["stock_and_cache_dividend"]),
                    "除息資料不合",
                )
                dividends[ds] = format(number(r[5]).normalize(), "f")
    require(set(dividends) == set(fm), "股利日期不合")
    result = []
    for ds in dates:
        source = "TW_2404_" + ds[:7].replace("-", "")
        record = dict(
            date=ds,
            code="2404",
            bar_source=source,
            shares_source="FM_2404_Shareholding",
            official_release=None,
            observed_by=None,
            price_downloaded_at=a.manifest[source]["downloaded_at"],
            shares_downloaded_at=a.manifest["FM_2404_Shareholding"]["downloaded_at"],
            event_cash=dividends.get(ds),
            strict_eod=False,
        )
        if ds not in prices or ds not in issued or ds not in official:
            record["status"] = "缺 K 或當日股數"
            result.append(record)
            continue
        r = official[ds]
        p = prices[ds]
        n = issued[ds]["NumberOfSharesIssued"]
        pairs = [
            (1, "Trading_Volume"),
            (2, "Trading_money"),
            (3, "open"),
            (4, "max"),
            (5, "min"),
            (6, "close"),
            (8, "Trading_turnover"),
        ]
        ok = all(number(r[i]) == number(p[name]) for i, name in pairs)
        if ds in anchors:
            require(n == anchors[ds], f"{ds} 發行股數不符")
        valid = (
            p["stock_id"] == issued[ds]["stock_id"] == "2404"
            and n > 0
            and 0 <= p["Trading_Volume"] <= n
            and 0 < p["min"] <= min(p["close"], p["open"]) <= max(p["close"], p["open"]) <= p["max"]
        )
        record.update(
            open=p["open"],
            high=p["max"],
            low=p["min"],
            close=p["close"],
            volume_shares=p["Trading_Volume"],
            amount_ntd=p["Trading_money"],
            issued_shares=n,
            declared_date=issued[ds]["RecentlyDeclareDate"],
            official_share_check=anchors.get(ds),
            turnover=p["Trading_Volume"] / n,
            status="回補值相符" if valid and ok else "行情或分母異常",
        )
        result.append(record)
    warm = []
    for n in (150, 200, 500):
        streak = []
        for i, r in enumerate(result):
            if r["status"] != "回補值相符":
                streak = []
                continue
            streak.append(r)
            if len(streak) == n:
                warm.append(
                    dict(
                        days=n,
                        start=streak[0]["date"],
                        nth_date=r["date"],
                        first_date_with_n_prior_sessions=dates[i + 1] if i + 1 < len(dates) else None,
                        initial_residual=prod(1 - v["turnover"] for v in streak[1:]),
                        strict_start=None,
                    )
                )
                break
    return result, warm, dividends


def samples(a):
    rows = []
    by_code = indexed(a.json("TPEx_日表")["tables"][0]["data"], 0)
    foreign = indexed(a.json("TPEx_股數")["tables"][0]["data"], 1)
    for code in ["3105", "1259", "3067"]:
        r = by_code[code]
        n = int(number(r[15]))
        require(n == number(foreign[code][3]), "上櫃兩表發行股數不符")
        if code in ("3105", "3067"):
            p = indexed(a.json("FM_" + code + "_Price")["data"], "date")["2026-11-13"]
            issued = indexed(a.json("FM_" + code + "_Shareholding")["data"], "date")["2026-11-13"]
            require(
                number(r[8]) == p["Trading_Volume"]
                and number(r[9]) == p["Trading_money"]
                and n == issued["NumberOfSharesIssued"],
                "上櫃備援不符",
            )
        rows.append(
            dict(
                date="2026-11-13",
                market="上櫃",
                code=code,
                name=r[1],
                volume_shares=int(number(r[8])),
                amount_ntd=int(number(r[9])),
                issued_shares=n,
                open=r[4],
                high=r[5],
                low=r[6],
                close=r[2],
                note="日表明列零成交，OHLC 缺值" if number(r[8]) == 0 else "日表精確股數",
            )
        )
    month = a.json("TPEx_3105_月表")["tables"][0]
    fm = indexed(a.json("FM_3105_Price")["data"], "date")
    require("成交張數" in month["fields"], "櫃買月表單位變動")
    for r in month["data"]:
        ds = roc(r[0])
        if ds > CUTOFF:
            continue
        p = fm[ds]
        require(
            all(
                number(r[i]) == number(p[n]) for i, n in [(3, "open"), (4, "max"), (5, "min"), (6, "close")]
            ),
            "上櫃 OHLC 不合",
        )
        rows.append(
            dict(
                date=ds,
                market="上櫃",
                code="3105",
                name="穩懋",
                volume_shares=p["Trading_Volume"],
                displayed_lots=int(number(r[1])),
                amount_ntd=p["Trading_money"],
                note="備援精確股數；月表 OHLC 對照",
            )
        )
    for code, ym in [("4763", "202506"), ("2888", "202507"), ("7867", "202610"), ("2330", "202611")]:
        tab = a.json(f"TW_{code}_{ym}")
        for r in tab["data"]:
            ds = roc(r[0])
            if ds > CUTOFF:
                continue
            rows.append(
                dict(
                    date=ds,
                    market="上市",
                    code=code,
                    name=tab["title"].split()[2],
                    volume_shares=int(number(r[1])),
                    amount_ntd=int(number(r[2])),
                    open=r[3],
                    high=r[4],
                    low=r[5],
                    close=r[6],
                    note=r[9] if len(r) > 9 else "",
                )
            )
    require(any(r[:3] == ["114/07/24", "新光金", "2888"] for r in a.json("下市")["data"]), "缺終止上市實據")
    require(any(r[0] == "7867" and r[9] == "115.10.30" for r in a.json("新上市")["data"]), "缺新上市實據")
    split = next(r for r in a.json("面額變更")["data"] if r[1] == "4763")
    require(
        number(split[3]) / number(split[4]) == 10 and split[:5] == a.json("分割明細")["data"][0][:5],
        "分割價格不符",
    )
    shares = indexed(a.json("FM_4763_Shareholding")["data"], "date")
    for ds in ("2025-06-18", "2025-06-27", "2025-06-30"):
        table = a.json("TW_股數_" + ds.replace("-", ""))["data"]
        require(number(indexed(table, 0)["4763"][3]) == shares[ds]["NumberOfSharesIssued"], "分割股數不符")
    require(
        shares["2025-06-27"]["NumberOfSharesIssued"] == 10 * shares["2025-06-18"]["NumberOfSharesIssued"],
        "換股比例不符",
    )
    return rows
