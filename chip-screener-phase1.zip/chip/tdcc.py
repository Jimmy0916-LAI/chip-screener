import re
from http.cookiejar import CookieJar
from html.parser import HTMLParser
from urllib import request, parse

FORM = "https://www.tdcc.com.tw/portal/zh/smWeb/qryStock"


def historical(day):
    session = request.build_opener(request.HTTPCookieProcessor(CookieJar()))
    with session.open(FORM, timeout=20) as page:
        html = page.read().decode()
    fields = dict(re.findall(r'<input type="hidden" name="([^"]+)" value="([^"]*)"', html))
    fields.update(scaDate=day.replace("-", ""), sqlMethod="StockNo", stockNo="2404", stockName="")
    req = request.Request(FORM, data=parse.urlencode(fields).encode(), headers={"Referer": FORM})
    return session.open(req, timeout=25)


class TableRows(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows = []
        self.row = []
        self.cell = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.row = []
        if tag == "td":
            self.cell = []

    def handle_data(self, data):
        if self.cell is not None:
            self.cell.append(data)

    def handle_endtag(self, tag):
        if tag == "td" and self.cell is not None:
            self.row.append("".join(self.cell).strip())
            self.cell = None
        if tag == "tr" and self.row:
            self.rows.append(self.row)
