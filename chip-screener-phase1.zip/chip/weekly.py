import csv
import io
from datetime import date, datetime, time, timedelta
from .signal import Point, BANDS, classify, week
from .sources import COMMITS, CASE, CUTOFF
from .store import TZ
from .tdcc import TableRows


def require(condition, message):
    if not condition:
        raise ValueError(message)


def decimal(value):
    return f"{float(value):.9f}"


def levels(body, day):
    result = {}
    for r in csv.DictReader(io.StringIO(body.decode("utf-8-sig"))):
        if r["證券代號"].strip() != "2404":
            continue
        require(r["資料日期"] == day.replace("-", ""), "CSV 統計日不符")
        level = int(r["持股分級"])
        require(level not in result, "重複級距")
        result[level] = (int(r["人數"]), int(r["股數"]), r["占集保庫存數比例%"])
    require(set(result) == set(range(1, 18)), "級距不完整")
    require(all(min(result[n][:2]) >= 0 for n in [*range(1, 16), 17]), "股數或戶數為負")
    require(sum(result[n][1] for n in range(1, 17)) == result[17][1] > 0, "分母核對失敗")
    require(sum(result[n][0] for n in range(1, 16)) == result[17][0], "合計戶數不符")
    return result


def page_check(html, rows, day):
    p = TableRows()
    p.feed(html)
    require(
        "證券名稱：漢唐" in html and f"資料日期：{int(day[:4]) - 1911}年{day[5:7]}月{day[8:]}日" in html,
        "個股表查詢日期或名稱不符",
    )
    actual = {}
    for r in p.rows:
        if len(r) != 5 or not r[0].isdigit():
            continue
        # 官方網頁略去零差異數，合計列可能編 16；依列名定位。
        grade = 17 if "".join(r[1].split()) == "合計" else int(r[0])
        require(grade not in actual, "官方表有重複列")
        actual[grade] = (int(r[2].replace(",", "")), int(r[3].replace(",", "")))
    require(all(actual.get(n) == rows[n][:2] for n in [*range(1, 16), 17]), "官網與固定版不一致")


def weekly(a, days):
    activities = a.json("推送活動")
    public = a.json("備份性質")["private"] is False
    allpoints = {band: {} for band in BANDS}
    snapshots = []
    raw = []
    observation = {}
    for ds, sha in COMMITS.items():
        day = date.fromisoformat(ds)
        key = "TDCC_" + ds
        r = levels(a.raw(key), ds)
        if ds in CASE:
            page_check(a.raw("集保個股_" + ds).decode(), r, ds)
        refs = [
            x
            for x in activities
            if public
            and x["after"] == sha
            and x["activity_type"] == "push"
            and x["ref"] == "refs/heads/main"
        ]
        known = min((datetime.fromisoformat(x["timestamp"]).astimezone(TZ) for x in refs), default=None)
        observation[ds] = known.isoformat() if known else None
        require(day == max(d for d in days if week(d) == week(day)), "快照不是該週最後市場交易日")
        for level, (holders, shares, pct) in r.items():
            raw.append(
                dict(
                    snapshot=ds,
                    code="2404",
                    level=level,
                    holders=holders,
                    shares=shares,
                    source_display_pct=pct,
                    source=key,
                )
            )
        for band, (lo, hi) in BANDS.items():
            holders = sum(r[i][0] for i in range(lo, hi + 1))
            shares = sum(r[i][1] for i in range(lo, hi + 1))
            p = Point(day, known, shares, holders, r[17][1], r[17][0])
            allpoints[band][day] = p
            snapshots.append(
                dict(
                    snapshot=ds,
                    code="2404",
                    band=band,
                    shares=shares,
                    lots=shares / 1000,
                    holders=holders,
                    total_shares=p.total,
                    total_holders=p.total_holders,
                    percent_exact=str(p.percent),
                    percent=decimal(p.percent),
                    official_release=None,
                    observed_by=observation[ds],
                    downloaded_at=a.manifest[key]["downloaded_at"],
                    commit=sha,
                    public_push_id=refs[0]["id"] if refs else None,
                    source=key,
                )
            )
    replay = []
    sample_days = sorted(allpoints["400"])
    for i in range(2, len(sample_days)):
        window = sample_days[i - 2 : i + 1]
        if any(week(b) - week(a) != timedelta(days=7) for a, b in zip(window, window[1:])):
            continue
        push_times = [allpoints["400"][d].known for d in window]
        known = max(push_times) if all(push_times) else None
        decision_times = [("統計日收盤", datetime.combine(window[-1], time(13, 30), TZ))]
        if known:
            decision_times.append(("公開備份可得", known))
            opens = [
                datetime.combine(d, time(9), TZ)
                for d in days
                if week(d) == week(window[-1]) + timedelta(weeks=1)
            ]
            first = next((t for t in sorted(opens) if t > known), None)
            if first:
                decision_times.append(("觀察週第一個已可用開盤", first))
        for label, as_of in decision_times:
            for band, series in allpoints.items():
                outcome = classify(series, window, as_of)
                replay.append(
                    dict(
                        w0=window[0],
                        w1=window[1],
                        w2=window[2],
                        decision=label,
                        as_of=as_of.isoformat(),
                        band=band,
                        state=outcome["state"],
                        total_pp=decimal(outcome["total_pp"]) if "total_pp" in outcome else None,
                    )
                )
    current = a.raw("集保官方最新")
    latest_date = next(csv.DictReader(io.StringIO(current.decode("utf-8-sig"))))["資料日期"]
    current_matches = None
    if latest_date == CASE[-1].replace("-", ""):
        current_matches = current == a.raw("TDCC_" + CASE[-1])
        require(
            levels(current, CASE[-1]) == levels(a.raw("TDCC_" + CASE[-1]), CASE[-1]), "官方最新級距不一致"
        )
    expected = list(map(date.fromisoformat, CASE))
    week_start = week(expected[-1]) + timedelta(weeks=1)
    next_opens = [
        datetime.combine(d, time(9), TZ)
        for d in days
        if week(d) == week_start and d <= date.fromisoformat(CUTOFF)
    ]
    signals = []
    as_of = datetime.fromisoformat(CUTOFF + "T23:59:59+08:00")
    for band, points in allpoints.items():
        result = classify(points, expected, as_of)
        result.update(band=band)
        if "delta_pp" in result:
            known = max(points[d].known for d in expected)
            trade = min((s for s in next_opens if s > known), default=None)
            prev = [date.fromisoformat("2026-10-22"), *expected[:2]]
            result.update(
                first_qualifying_window=result["state"] == "通過"
                and classify(points, prev, as_of)["state"] != "通過",
                observation_week_open=trade.isoformat() if trade else None,
                eligible_open=trade.isoformat() if trade and result["state"] == "通過" else None,
                available_at=known.isoformat(),
            )
            for f in ["delta_pp", "total_pp"]:
                exact = result[f]
                result[f + "_exact"] = [str(x) for x in exact] if isinstance(exact, list) else str(exact)
                result[f] = [decimal(x) for x in exact] if isinstance(exact, list) else decimal(exact)
        signals.append(result)
    return (
        raw,
        snapshots,
        signals,
        replay,
        dict(current_date=latest_date, current_byte_match=current_matches, known=observation),
    )
