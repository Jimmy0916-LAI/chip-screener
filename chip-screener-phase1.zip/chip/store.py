"""以 SHA-256 保留原始 HTTP 本文，各次查詢另存不可變清單。"""

import gzip
import hashlib
import json
import os
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from pathlib import Path
from urllib.request import Request, urlopen
from .sources import catalog
from .tdcc import historical

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "evidence"
TZ = timezone(timedelta(hours=8))


def now():
    return datetime.now(TZ).isoformat(timespec="microseconds")


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix("." + uuid.uuid4().hex + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def fetch(item):
    key, url = item
    for attempt in range(2):
        try:
            if key.startswith("集保個股_"):
                response = historical(key.split("_")[1])
            else:
                response = urlopen(Request(url, headers={"User-Agent": "TaiwanChipSample/0.1"}), timeout=25)
            with response as r:
                body = r.read()
                retrieved = now()
                headers = {s: r.headers.get(s) for s in ("Date", "ETag", "Last-Modified")}
            if key.startswith("TDCC_") or key == "集保官方最新":
                if not body.decode("utf-8-sig").startswith("資料日期,證券代號,持股分級,人數,股數,"):
                    raise ValueError("未取得預期 CSV")
            elif key.startswith("集保個股_"):
                if "證券名稱：漢唐" not in body.decode():
                    raise ValueError("指定個股歷史表未取得")
            elif key.startswith("公告_"):
                term = {
                    "公告_除息": "現金股息40元",
                    "公告_分割": "11:19:15",
                    "公告_漢唐股數": "190,586,698",
                }[key]
                if term not in body.decode():
                    raise ValueError("公告本文未取得")
            elif key != "備份說明":
                parsed = json.loads(body)
                if isinstance(parsed, dict):
                    status = parsed.get("status", parsed.get("stat", "OK"))
                    if str(status).lower() not in ("200", "ok") or parsed.get("success") is False:
                        raise ValueError(str(status))
            digest = hashlib.sha256(body).hexdigest()
            raw = DATA / "raw" / (digest + ".gz")
            raw.parent.mkdir(parents=True, exist_ok=True)
            if not raw.exists():
                tmp = raw.with_suffix("." + uuid.uuid4().hex + ".tmp")
                tmp.write_bytes(gzip.compress(body, mtime=0))
                os.replace(tmp, raw)
            return key, dict(
                url=url, downloaded_at=retrieved, sha256=digest, bytes=len(body), headers=headers
            )
        except (ValueError, OSError) as exc:
            error = str(exc)
            time.sleep(0.3 * (attempt + 1))
    return key, dict(url=url, attempted_at=now(), error=error)


def download():
    run = datetime.now(TZ).strftime("%Y%m%dT%H%M%S%f")
    with ThreadPoolExecutor(4) as pool:
        items = dict(pool.map(fetch, catalog().items()))
    write_json(DATA / "runs" / (run + ".json"), items)
    errors = [(k, v["error"]) for k, v in items.items() if "error" in v]
    print(run, len(items), "來源，失敗", errors)
    if errors:
        raise SystemExit("此次抓取有缺漏。上次完整清單保留在 evidence/latest.txt")
    return run


class Archive:
    def __init__(self, run):
        self.run = run
        self.manifest = json.loads((DATA / "runs" / (run + ".json")).read_text(encoding="utf-8"))

    def raw(self, key):
        meta = self.manifest[key]
        b = gzip.decompress((DATA / "raw" / (meta["sha256"] + ".gz")).read_bytes())
        if hashlib.sha256(b).hexdigest() != meta["sha256"]:
            raise ValueError(f"原檔雜湊不符 {key}")
        return b

    def json(self, key):
        return json.loads(self.raw(key))
