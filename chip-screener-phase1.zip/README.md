# 台股籌碼研究｜第一輪資料驗收

本專案依需求文件內文 v0.4，由空白專案開始。研究截點為台北時間 2026-11-19 收盤，11-20 凌晨下載。第一輪凍結版為 `20261120T021433143982`。實測與未通過範圍見 `第一輪驗收.md`。

## 在 Windows PowerShell 重跑

解壓縮，在看得到 `audit.py` 的專案根目錄執行。使用 Python 3.11 以上，僅用標準函式庫。實測環境為 Linux、Python 3.12.14。PowerShell 可用 Windows Python Launcher 將相同參數傳給 Python。

```powershell
py -3 --version
py -3 audit.py --run 20261120T021433143982
py -3 -m unittest discover -s tests -v
py -3 audit.py --status
```

使用線上來源重新取樣。這一步需要連網，全程匿名。下載及內容驗收通過後才把最新成功版本寫入 `evidence/latest.txt`。後續預設離線讀此版本。

```powershell
py -3 audit.py --fetch
py -3 audit.py
$id = (Get-Content .\evidence\latest.txt -Raw).Trim()
Import-Csv ".\reports\$id\weekly.csv" | Where-Object { $_.band -eq '400' } | Format-Table snapshot,shares,total_shares,percent,observed_by
Get-Content ".\reports\$id\result.json" -Encoding UTF8 -Raw
```

本次實際執行 `python audit.py --fetch`、`python audit.py`、`python audit.py --run 20261120T021433143982`、`python audit.py --status` 與 `python -m unittest discover -s tests -v`。在已將 Python 加入 PATH 的 Windows 環境，也可直接使用這些指令。

## 檔案及重現方式

| 位置 | 內容 |
|---|---|
| `evidence/runs/<版本>.json` | 每個取樣的 URL、下載完成時間、HTTP 標頭、位元組數、解壓後 SHA-256 或錯誤。每次抓取另存一份。 |
| `evidence/raw/<SHA-256>.gz` | 原始 HTTP 本文的無損 gzip。相同內容只存一份。CSV、JSON 與 HTML 均可依法重查來源。 |
| `reports/<版本>/coverage.csv` | 每個來源實際抽樣期間、股票、欄位單位、限制、公開證據、下載時間、URL 與原檔路徑。以 source 連至其他明細。 |
| `reports/<版本>/levels.csv` | 漢唐各期 CSV 原始 1–17 級。source_display_pct 是來源顯示值。 |
| `reports/<版本>/weekly.csv` | 每期四條累計線與 400–1,000 張互斥段。含股數、戶數、分母、分數精確值、已公開上界及版本。 |
| `reports/<版本>/replay.csv` | 三個連續週窗，在統計日收盤、公開備份可得及觀察週開盤逐級距重播。 |
| `reports/<版本>/result.json` | 兩週變動、比較設定、可用時間、暖機殘留與嚴格歷史狀態。 |
| `reports/<版本>/daily_2404.csv` | 日 K、成交股數、金額、發行股數、當日換手率、查核、除息與可知時間。 |
| `reports/<版本>/market_samples.csv` | 掛牌、下市、停牌、零量、上櫃精確股數等案例。上櫃日表與月表比對列可按 note 區分。 |
| `tests/cases.json`、`tests/test_audit.py` | 合成輸入、預期、真實三期回歸、時間邊界、來源失敗及離線一致性測試。 |
| `chip/sources.py`、`chip/tdcc.py` | 固定日期、commit 與查詢方法；官方個股表採含 session 的 POST。 |
| `chip/signal.py` | 掃描及歷史重播共用 `classify(points, expected, as_of, minimum_pp)`。比例變化以分數運算。 |

`snapshot/date` 表示統計日或交易日。事件的現金除息日、換股基準日和恢復交易日個別記錄。`official_release` 留給可核對的公告時刻。`observed_by` 或 `historical_observed_by` 是本輪找到的公開時間證據上界，`downloaded_at` 是本次抓取。空白表示缺該項證據。下載只證明本次取樣時可得。CSV 採 UTF-8 BOM。所有交易及可用時點使用台北時間，HTTP 原標頭與 GitHub 原回應保留原時區。

重新上網抓取同一範圍會產生新版本。最新 CSV、GitHub 活動列表、官網一年期歷史、當月月表及事後修訂都可能改變。當月日線分析截到 11-19。回看本次結論可指定固定版本，完全離線。下載失敗可用 `--status` 查拒絕原因、用 `--fetch` 補跑；驗收失敗仍可重播最後成功的結果。回到特定舊版使用 `--run`。這些指令處理研究樣本，沒有背景排程。

下一階段可直接依 `weekly.csv` 的級距欄位切換手機圖線，或讓每日掃描與重播對同一時點呼叫 `classify`。進階設定、A/B 的版本化方案及手機操作依原規格保留；目前交付資料接入、共用週訊號和第一輪驗收工具。
