"""一鍵打包 ChipScreener 輕量熱更發佈包、Windows 完整初始包、免環境依賴獨立版與 manifest.json 工具
流程：
1. 依版本號與通道更新 scripts/release_meta.json
2. 執行 scripts/build_dashboard.py 重新編譯 build/dashboard.html（除非指定 --skip-build）
3. 產出熱更包：僅打包 build/dashboard.html 與 scripts/（排除 __pycache__ / *.pyc 與 data/ 基線、用戶資料）
4. 產出完整初始包（可用 include_full / 非 --no-full）：打包 ChipScreener.exe、啟動批處理、package.json、README.md、build/、data/、scripts/、src/
5. 產出免環境依賴獨立包（--standalone / pack_standalone）：內嵌官方 Windows Embeddable Python 3.10.11 與編譯版 ChipScreener.exe，無需安裝 Python/Node.js 即可解壓雙擊使用
6. 計算熱更或獨立 ZIP 檔 SHA-256 校驗碼
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = ROOT / 'scripts'
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

import build_dashboard  # noqa: E402
from providers.updater import DEFAULT_REPO, normalize_repo, read_install_shell_version  # noqa: E402

TAIPEI_TZ = timezone(timedelta(hours=8))
FULL_TOP_FILES = ('ChipScreener.exe', '啟動籌碼雷達.bat', 'package.json', 'README.md')
FULL_DIRS = ('build', 'data', 'scripts', 'src')
FULL_SKIP_PARTS = frozenset({'.git', '.idea', '__pycache__', 'node_modules', 'dist', 'mobile'})
FULL_SKIP_SUFFIXES = frozenset({'.pyc', '.pyo', '.iml'})

EMBED_PY_URL = 'https://www.python.org/ftp/python/3.10.11/python-3.10.11-embed-amd64.zip'
EMBED_PY_SHA256 = '608619f8619075629c9c69f361352a0da6ed7e62f83a0e19c63e0ea32eb7629d'

README_STANDALONE = """台股籌碼雷達 (ChipScreener) v{version} 免安裝完整版
====================================================

使用方式（無須安裝 Python、Node.js 或任何系統環境）：
1. 請將整個壓縮檔「全部解壓縮」至任意資料夾（支援中文與空格路徑）。
2. 雙擊「ChipScreener.exe」即可自動啟動本機服務並開啟籌碼雷達視窗。

資料隔離與更新說明：
- 所有自選收藏夾、模擬交易紀錄、每日晨報設定、軟體更新設定與快取均安全保存於 Windows：
  %LOCALAPPDATA%\\ChipScreener\\
- 程式資料夾可直接搬移或替換新版，您的個人設定與資料不會遺失。
"""


def _infer_channel(version: str, channel: str | None) -> str:
    if channel in ('stable', 'beta'):
        return channel
    low = version.lower()
    if '-' in version and any(tag in low for tag in ('beta', 'alpha', 'rc', '-t')):
        return 'beta'
    return 'stable'


def _ensure_embed_python_zip() -> Path:
    local_app_data = Path(os.environ.get('LOCALAPPDATA') or Path.home())
    cache_path = local_app_data / 'ChipScreener' / 'build-cache' / 'python-3.10.11-embed-amd64.zip'
    cache_path.parent.mkdir(parents=True, exist_ok=True)
    if cache_path.is_file():
        if hashlib.sha256(cache_path.read_bytes()).hexdigest().lower() == EMBED_PY_SHA256:
            return cache_path
        cache_path.unlink()

    print('[embed] 正在下載官方 Windows 輕量 Python 3.10.11 執行環境...', flush=True)
    urllib.request.urlretrieve(EMBED_PY_URL, cache_path)
    actual_sha = hashlib.sha256(cache_path.read_bytes()).hexdigest().lower()
    if actual_sha != EMBED_PY_SHA256:
        cache_path.unlink(missing_ok=True)
        raise RuntimeError(f'Embed Python SHA-256 校驗失敗：{actual_sha}')
    return cache_path


def compile_launcher_exe(out_exe: Path) -> Path:
    csc_candidates = [
        Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'),
        Path(r'C:\Windows\Microsoft.NET\Framework\v4.0.30319\csc.exe'),
    ]
    csc = next((p for p in csc_candidates if p.is_file()), None)
    if not csc:
        raise FileNotFoundError('找不到 .NET Framework csc.exe，無法編譯 ChipScreener.exe')

    cs_src = SCRIPTS_DIR / 'launcher_exe.cs'
    out_exe.parent.mkdir(parents=True, exist_ok=True)
    cmd = [
        str(csc),
        '/nologo',
        '/target:winexe',
        '/optimize+',
        f'/out:{out_exe}',
        '/reference:System.Windows.Forms.dll',
        '/reference:System.Drawing.dll',
        str(cs_src),
    ]
    res = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='replace')
    if res.returncode != 0 or not out_exe.is_file():
        raise RuntimeError(f'編譯 ChipScreener.exe 失敗：\n{res.stdout}\n{res.stderr}')
    return out_exe


def _pack_full_windows_zip(target_out: Path, clean_ver: str) -> tuple[Path, str, int, int]:
    """產出不含 .git / .idea / 快取之 Windows 完整初始包。"""
    full_name = f'ChipScreener-Windows-{clean_ver}-full.zip'
    full_path = target_out / full_name
    count = 0
    with zipfile.ZipFile(full_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for name in FULL_TOP_FILES:
            p = ROOT / name
            if p.is_file():
                zf.write(p, name)
                count += 1
        for d in FULL_DIRS:
            dir_path = ROOT / d
            if not dir_path.is_dir():
                continue
            for p in sorted(dir_path.rglob('*')):
                if not p.is_file():
                    continue
                rel = p.relative_to(ROOT).as_posix()
                if any(part in FULL_SKIP_PARTS for part in rel.split('/')) or p.suffix.lower() in FULL_SKIP_SUFFIXES:
                    continue
                zf.write(p, rel)
                count += 1
    full_bytes = full_path.read_bytes()
    return full_path, hashlib.sha256(full_bytes).hexdigest().lower(), len(full_bytes), count


def pack_release(
    version: str,
    channel: str | None = None,
    min_shell: str | None = None,
    repo: str = DEFAULT_REPO,
    tag: str | None = None,
    changelog: list[str] | None = None,
    out_dir: Path | None = None,
    skip_build: bool = False,
    dry_meta_restore: bool = False,
    include_full: bool = False,
) -> dict:
    clean_ver = str(version or '').strip().lstrip('vV')
    if not clean_ver:
        raise ValueError('請提供發佈版號（例如 0.6.1 或 0.6.2-beta.1）')

    resolved_channel = channel or ('beta' if ('-' in clean_ver and 'beta' in clean_ver.lower()) else 'stable')
    if resolved_channel not in ('stable', 'beta'):
        raise ValueError('channel 僅支援 stable 或 beta')

    repo_slug = normalize_repo(repo)
    shell_min = (min_shell or read_install_shell_version(ROOT)).strip()
    release_tag = tag or f'v{clean_ver}'
    now_iso = datetime.now(TAIPEI_TZ).isoformat(timespec='seconds')

    notes = [line.strip() for line in (changelog or []) if line and line.strip()]
    if not notes:
        notes = [f'ChipScreener {clean_ver}（{resolved_channel}）熱更更新包']

    meta_file = SCRIPTS_DIR / 'release_meta.json'
    dashboard_file = ROOT / 'build' / 'dashboard.html'
    prev_meta_raw = meta_file.read_text(encoding='utf-8') if meta_file.exists() else None
    prev_dash_bytes = dashboard_file.read_bytes() if (dry_meta_restore and not skip_build and dashboard_file.is_file()) else None
    meta_doc = {
        'appVersion': clean_ver,
        'channel': resolved_channel,
        'builtAt': now_iso,
        'changelog': notes,
    }
    meta_file.write_text(json.dumps(meta_doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    try:
        if not skip_build:
            build_dashboard.build()

        if not dashboard_file.is_file():
            raise FileNotFoundError(f'找不到建置產物：{dashboard_file}')

        target_out = out_dir or (ROOT / 'dist')
        target_out.mkdir(parents=True, exist_ok=True)
        asset_name = f'ChipScreener-runtime-{clean_ver}.zip'
        zip_path = target_out / asset_name

        file_count = 0
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
            zf.write(dashboard_file, 'build/dashboard.html')
            file_count += 1
            for p in sorted(SCRIPTS_DIR.rglob('*')):
                if not p.is_file():
                    continue
                rel = p.relative_to(ROOT).as_posix()
                if '__pycache__' in rel.split('/') or p.suffix in ('.pyc', '.pyo'):
                    continue
                zf.write(p, rel)
                file_count += 1

        zip_bytes = zip_path.read_bytes()
        sha256 = hashlib.sha256(zip_bytes).hexdigest().lower()

        manifest_path = target_out / 'manifest.json'
        if manifest_path.exists():
            try:
                manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
            except Exception:
                manifest = {}
        else:
            manifest = {}

        if not isinstance(manifest, dict):
            manifest = {}
        channels = manifest.get('channels')
        if not isinstance(channels, dict):
            channels = {}

        channels[resolved_channel] = {
            'appVersion': clean_ver,
            'minShellVersion': shell_min,
            'assetName': asset_name,
            'bundleUrl': f'https://github.com/{repo_slug}/releases/download/{release_tag}/{asset_name}',
            'shellDownloadUrl': f'https://github.com/{repo_slug}/releases/tag/{release_tag}',
            'sha256': sha256,
            'sizeBytes': len(zip_bytes),
            'changelog': notes,
            'publishedAt': now_iso,
        }

        manifest['schemaVersion'] = 1
        manifest['updatedAt'] = now_iso
        manifest['repo'] = repo_slug
        manifest['channels'] = channels
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

        result = {
            'version': clean_ver,
            'channel': resolved_channel,
            'minShellVersion': shell_min,
            'zipPath': str(zip_path),
            'manifestPath': str(manifest_path),
            'sha256': sha256,
            'sizeBytes': len(zip_bytes),
            'fileCount': file_count,
        }
        if include_full:
            full_path, full_sha, full_size, full_count = _pack_full_windows_zip(target_out, clean_ver)
            result.update({
                'fullZipPath': str(full_path),
                'fullSha256': full_sha,
                'fullSizeBytes': full_size,
                'fullFileCount': full_count,
            })
        return result
    finally:
        if dry_meta_restore and prev_meta_raw is not None:
            meta_file.write_text(prev_meta_raw, encoding='utf-8')
        if dry_meta_restore and prev_dash_bytes is not None:
            dashboard_file.write_bytes(prev_dash_bytes)


def pack_standalone(
    version: str,
    channel: str | None = None,
    out_dir: Path | None = None,
    also_compile_root_exe: bool = True,
) -> dict:
    """產出完全不需要預裝 Python / Node.js 即可下載雙擊使用的 Windows 獨立可攜版 ZIP。"""
    clean_ver = str(version or '').strip().lstrip('vV')
    if not clean_ver:
        raise ValueError('請提供發佈版號（例如 0.6.1-t）')
    resolved_channel = _infer_channel(clean_ver, channel)
    now_iso = datetime.now(TAIPEI_TZ).isoformat(timespec='seconds')

    embed_zip = _ensure_embed_python_zip()
    target_out = out_dir or (ROOT / 'dist')
    target_out.mkdir(parents=True, exist_ok=True)
    bundle_root_name = f'ChipScreener-v{clean_ver}'
    zip_name = f'ChipScreener-v{clean_ver}-Windows-x64.zip'
    zip_path = target_out / zip_name

    dashboard_file = ROOT / 'build' / 'dashboard.html'
    prev_dash_bytes = dashboard_file.read_bytes() if dashboard_file.is_file() else None
    build_dashboard.build(shell_version=clean_ver, app_version=clean_ver, channel=resolved_channel)
    built_dash_bytes = dashboard_file.read_bytes()
    if prev_dash_bytes is not None:
        dashboard_file.write_bytes(prev_dash_bytes)

    with tempfile.TemporaryDirectory() as tmp:
        stage_dir = Path(tmp) / bundle_root_name
        stage_dir.mkdir(parents=True, exist_ok=True)

        exe_path = compile_launcher_exe(stage_dir / 'ChipScreener.exe')
        if also_compile_root_exe:
            shutil.copy2(exe_path, ROOT / 'ChipScreener.exe')

        rt_py = stage_dir / 'runtime-python'
        rt_py.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(embed_zip, 'r') as ezf:
            ezf.extractall(rt_py)
        pth_file = rt_py / 'python310._pth'
        pth_file.write_text('python310.zip\n.\n..\n..\\scripts\n', encoding='utf-8')

        pkg_doc = json.loads((ROOT / 'package.json').read_text(encoding='utf-8'))
        pkg_doc['version'] = clean_ver
        pkg_doc['description'] = f'台股籌碼雷達 ChipScreener v{clean_ver} 免安裝獨立版'
        (stage_dir / 'package.json').write_text(json.dumps(pkg_doc, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

        (stage_dir / 'build').mkdir(parents=True, exist_ok=True)
        (stage_dir / 'build' / 'dashboard.html').write_bytes(built_dash_bytes)

        data_dst = stage_dir / 'data'
        data_dst.mkdir(parents=True, exist_ok=True)
        for fname in ('feed-base.json', 'web_data.json', 'sp500_universe.json', 'chip-screener-phase1.zip'):
            src = ROOT / 'data' / fname
            if src.is_file():
                shutil.copy2(src, data_dst / fname)

        scripts_dst = stage_dir / 'scripts'
        for p in sorted(SCRIPTS_DIR.rglob('*')):
            if not p.is_file():
                continue
            rel = p.relative_to(SCRIPTS_DIR)
            if '__pycache__' in rel.parts or p.suffix in ('.pyc', '.pyo'):
                continue
            dest = scripts_dst / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dest)

        (scripts_dst / 'release_meta.json').write_text(
            json.dumps({'appVersion': clean_ver, 'channel': resolved_channel, 'builtAt': now_iso}, ensure_ascii=False, indent=2) + '\n',
            encoding='utf-8',
        )
        (stage_dir / '使用說明_README.txt').write_text(README_STANDALONE.format(version=clean_ver), encoding='utf-8')

        file_count = 0
        with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as out_zf:
            for item in sorted(stage_dir.rglob('*')):
                if item.is_file():
                    out_zf.write(item, item.relative_to(stage_dir.parent).as_posix())
                    file_count += 1

    zip_bytes = zip_path.read_bytes()
    sha256 = hashlib.sha256(zip_bytes).hexdigest().lower()
    (target_out / f'{zip_name}.sha256').write_text(f'{sha256} *{zip_name}\n', encoding='utf-8')

    return {
        'version': clean_ver,
        'channel': resolved_channel,
        'zipPath': str(zip_path),
        'sha256Path': str(target_out / f'{zip_name}.sha256'),
        'sha256': sha256,
        'sizeBytes': len(zip_bytes),
        'sizeMB': round(len(zip_bytes) / (1024 * 1024), 2),
        'fileCount': file_count,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description='ChipScreener 一鍵打包輕量熱更發佈包、完整包與獨立免依賴版')
    parser.add_argument('--version', required=True, help='目標版號（例：0.6.1-t 或 0.6.1）')
    parser.add_argument('--channel', choices=['stable', 'beta'], default=None, help='發布通道（未指定時依版號自動判斷）')
    parser.add_argument('--min-shell', default=None, help='最低要求外殼版號（預設讀取 package.json）')
    parser.add_argument('--repo', default=DEFAULT_REPO, help='GitHub Repo（owner/repo）')
    parser.add_argument('--tag', default=None, help='Release Tag（預設 v<version>）')
    parser.add_argument('--changelog', action='append', default=[], help='更新摘要項目（可重複指定）')
    parser.add_argument('--out-dir', default=None, help='輸出目錄（預設 dist/）')
    parser.add_argument('--skip-build', action='store_true', help='略過重新編譯 build/dashboard.html')
    parser.add_argument('--restore-meta', action='store_true', help='打包後還原工作區 release_meta.json 與 dashboard.html（適用測試打包）')
    parser.add_argument('--no-full', action='store_true', help='略過產出 Windows 完整初始包（僅產出熱更包與 manifest.json）')
    parser.add_argument('--standalone', action='store_true', help='打包免安裝、免 Python／Node 依賴之 Windows x64 獨立版 ZIP')
    args = parser.parse_args()

    out_path = Path(args.out_dir) if args.out_dir else None
    if args.standalone:
        res = pack_standalone(
            version=args.version,
            channel=args.channel,
            out_dir=out_path,
        )
    else:
        res = pack_release(
            version=args.version,
            channel=args.channel,
            min_shell=args.min_shell,
            repo=args.repo,
            tag=args.tag,
            changelog=args.changelog,
            out_dir=out_path,
            skip_build=args.skip_build,
            dry_meta_restore=args.restore_meta,
            include_full=not args.no_full,
        )
    print(json.dumps(res, ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
